# STC 单片机烧录工具（Linux GUI）

这是一个 Tkinter 图形前端，调用你已经安装的 `stcgal` 执行烧录，不是 STC 官方软件。

## 运行要求
- Ubuntu / Linux
- Python 3 + Tkinter
- 已安装 stcgal（默认路径：`~/.venvs/stc/bin/stcgal`）

## 启动
在解压目录中运行：

```bash
python3 stc_flash_gui.py
```

如果提示缺少 tkinter：

```bash
sudo apt install python3-tk
```

## 功能
- 选择 HEX / IHX / BIN 文件
- 选择 STC 协议和串口
- 设置传输波特率、握手波特率
- 可选 DTR 自动复位
- 实时显示 stcgal 输出日志

## 注意
- 默认协议为 `stc15`，但实际协议/芯片兼容性需以你的具体 STC15F2K60S2 板卡和 stcgal 版本为准。
- `--autoreset` 需要适配器的 DTR 接线支持；若不确定，请不要勾选。
- 烧录前确认串口设备、接线、电源和目标芯片，避免选错串口。
- 串口权限问题可检查 `groups` 是否包含 `dialout`。加入组后需注销并重新登录。
- 本程序只是 stcgal 的图形化前端，不会自行验证烧录内容或保证硬件兼容性。
