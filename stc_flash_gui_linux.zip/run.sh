#!/usr/bin/env bash
set -e
APP_DIR="$HOME/.local/share/stc-flash-gui"
mkdir -p "$APP_DIR"
cp "$(dirname "$0")/stc_flash_gui.py" "$APP_DIR/stc_flash_gui.py"
chmod +x "$APP_DIR/stc_flash_gui.py"
exec python3 "$APP_DIR/stc_flash_gui.py"
