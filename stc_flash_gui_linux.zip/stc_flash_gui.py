#!/usr/bin/env python3
"""
STC Flash GUI for Linux
A lightweight Tkinter graphical front-end for stcgal.
Supports selecting HEX/BIN files, serial ports, STC protocol, baud rate,
and displays the programming log.
"""
import os
import sys
import shutil
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

APP_TITLE = "STC 单片机烧录工具"
DEFAULT_STCGAL = str(Path.home() / ".venvs/stc/bin/stcgal")

def find_stcgal():
    candidates = [
        DEFAULT_STCGAL,
        shutil.which("stcgal"),
        str(Path.home() / ".local/bin/stcgal"),
    ]
    for candidate in candidates:
        if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return ""

def serial_ports():
    ports = []
    dev = Path("/dev")
    patterns = ("ttyUSB*", "ttyACM*", "ttyS*", "ttyAMA*", "ttyTHS*")
    for pattern in patterns:
        ports.extend(str(p) for p in dev.glob(pattern))
    return sorted(set(ports))

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("760x600")
        self.minsize(650, 500)
        self.proc = None
        self.running = False

        root = ttk.Frame(self, padding=14)
        root.pack(fill="both", expand=True)

        ttk.Label(root, text="STC 单片机烧录工具", font=("", 17, "bold")).pack(anchor="w")
        ttk.Label(root, text="Linux 图形前端 · 使用已安装的 stcgal 执行烧录").pack(anchor="w", pady=(2, 12))

        file_row = ttk.Frame(root)
        file_row.pack(fill="x", pady=4)
        ttk.Label(file_row, text="HEX / BIN 文件：", width=14).pack(side="left")
        self.file_var = tk.StringVar()
        ttk.Entry(file_row, textvariable=self.file_var).pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(file_row, text="选择文件…", command=self.pick_file).pack(side="left")

        options = ttk.LabelFrame(root, text="烧录设置", padding=10)
        options.pack(fill="x", pady=10)

        row1 = ttk.Frame(options)
        row1.pack(fill="x", pady=4)
        ttk.Label(row1, text="芯片协议：", width=12).pack(side="left")
        self.protocol = tk.StringVar(value="stc15")
        ttk.Combobox(row1, textvariable=self.protocol, state="readonly",
                     values=["auto", "stc15", "stc15a", "stc12", "stc12a", "stc12b", "stc89", "stc89a", "stc8"],
                     width=12).pack(side="left")
        ttk.Label(row1, text="串口：", padding=(18, 0, 0, 0)).pack(side="left")
        self.port = tk.StringVar()
        self.port_box = ttk.Combobox(row1, textvariable=self.port, values=serial_ports(), width=22)
        self.port_box.pack(side="left", padx=6)
        ttk.Button(row1, text="刷新串口", command=self.refresh_ports).pack(side="left")

        row2 = ttk.Frame(options)
        row2.pack(fill="x", pady=4)
        ttk.Label(row2, text="波特率：", width=12).pack(side="left")
        self.baud = tk.StringVar(value="115200")
        ttk.Combobox(row2, textvariable=self.baud, state="readonly",
                     values=["115200", "57600", "38400", "19200", "9600"], width=12).pack(side="left")
        ttk.Label(row2, text="握手波特率：").pack(side="left", padx=(18, 0))
        self.handshake = tk.StringVar(value="2400")
        ttk.Combobox(row2, textvariable=self.handshake, state="readonly",
                     values=["2400", "4800", "1200", "9600"], width=12).pack(side="left")

        row3 = ttk.Frame(options)
        row3.pack(fill="x", pady=4)
        self.autoreset = tk.BooleanVar(value=False)
        ttk.Checkbutton(row3, text="尝试通过 DTR 自动复位（仅适用于支持该接线的适配器）",
                        variable=self.autoreset).pack(side="left")

        self.stcgal_var = tk.StringVar(value=find_stcgal())
        path_row = ttk.Frame(root)
        path_row.pack(fill="x", pady=(0, 8))
        ttk.Label(path_row, text="stcgal 路径：", width=14).pack(side="left")
        ttk.Entry(path_row, textvariable=self.stcgal_var).pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(path_row, text="浏览…", command=self.pick_stcgal).pack(side="left")

        buttons = ttk.Frame(root)
        buttons.pack(fill="x", pady=4)
        self.flash_btn = ttk.Button(buttons, text="开始烧录", command=self.start_flash)
        self.flash_btn.pack(side="left")
        ttk.Button(buttons, text="清空日志", command=self.clear_log).pack(side="left", padx=8)
        ttk.Button(buttons, text="检查工具", command=self.check_tool).pack(side="left")

        ttk.Label(root, text="运行日志：").pack(anchor="w", pady=(8, 3))
        log_frame = ttk.Frame(root)
        log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(log_frame, height=14, wrap="word", state="disabled")
        scroll = ttk.Scrollbar(log_frame, command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.write_log("提示：选择 HEX/BIN 文件和串口后开始。烧录时请按工具提示给目标板重新上电。")
        if not self.stcgal_var.get():
            self.write_log("未自动找到 stcgal，请确认已安装，或手动填写路径。")

    def write_log(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", msg.rstrip() + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def pick_file(self):
        filename = filedialog.askopenfilename(
            title="选择要烧录的程序文件",
            filetypes=[("Intel HEX / Binary", "*.hex *.ihx *.ihex *.bin"), ("所有文件", "*.*")]
        )
        if filename:
            self.file_var.set(filename)

    def pick_stcgal(self):
        filename = filedialog.askopenfilename(title="选择 stcgal 可执行文件")
        if filename:
            self.stcgal_var.set(filename)

    def refresh_ports(self):
        ports = serial_ports()
        self.port_box["values"] = ports
        if self.port.get() not in ports:
            self.port.set(ports[0] if ports else "")
        self.write_log("串口列表已刷新：" + (", ".join(ports) if ports else "未发现常见串口设备"))

    def check_tool(self):
        path = self.stcgal_var.get().strip()
        if not path or not os.path.isfile(path) or not os.access(path, os.X_OK):
            messagebox.showerror("找不到 stcgal", "请检查 stcgal 路径。\n默认安装路径通常是 ~/.venvs/stc/bin/stcgal")
            return
        try:
            result = subprocess.run([path, "-V"], capture_output=True, text=True, timeout=10)
            self.write_log("$ " + path + " -V")
            self.write_log((result.stdout + result.stderr).strip() or f"退出码：{result.returncode}")
            messagebox.showinfo("检查完成", "已运行 stcgal 版本检查，请查看日志。")
        except Exception as exc:
            messagebox.showerror("检查失败", str(exc))

    def start_flash(self):
        if self.running:
            return
        file_path = self.file_var.get().strip()
        port = self.port.get().strip()
        tool = self.stcgal_var.get().strip()
        protocol = self.protocol.get().strip()
        if not file_path or not os.path.isfile(file_path):
            messagebox.showwarning("缺少文件", "请先选择存在的 HEX 或 BIN 文件。")
            return
        if Path(file_path).suffix.lower() not in {".hex", ".ihx", ".ihex", ".bin"}:
            if not messagebox.askyesno("确认文件", "文件扩展名不是常见 HEX/BIN，仍要尝试烧录吗？"):
                return
        if not port:
            messagebox.showwarning("缺少串口", "请选择串口。若列表为空，请连接 USB 转串口适配器后点击“刷新串口”。")
            return
        if not tool or not os.path.isfile(tool) or not os.access(tool, os.X_OK):
            messagebox.showerror("找不到 stcgal", "请检查 stcgal 路径。")
            return
        try:
            baud = int(self.baud.get())
            handshake = int(self.handshake.get())
        except ValueError:
            messagebox.showerror("参数错误", "波特率必须是数字。")
            return

        cmd = [tool, "-P", protocol, "-p", port, "-b", str(baud), "-l", str(handshake)]
        if self.autoreset.get():
            cmd.append("-a")
        cmd.append(file_path)

        self.running = True
        self.flash_btn.configure(state="disabled")
        self.write_log("")
        self.write_log("$ " + " ".join(subprocess.list2cmdline([x]) for x in cmd))
        self.write_log("开始烧录；若提示重新上电，请按提示操作。")
        threading.Thread(target=self.run_process, args=(cmd,), daemon=True).start()

    def run_process(self, cmd):
        try:
            self.proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1
            )
            for line in self.proc.stdout:
                self.after(0, self.write_log, line.rstrip())
            code = self.proc.wait()
            self.after(0, self.write_log, f"\n进程结束，退出码：{code}")
            if code == 0:
                self.after(0, messagebox.showinfo, "烧录完成", "stcgal 已正常退出。请检查目标板运行情况。")
            else:
                self.after(0, messagebox.showwarning, "烧录未成功", "stcgal 返回非零退出码，请查看日志。")
        except Exception as exc:
            self.after(0, self.write_log, f"运行失败：{exc}")
            self.after(0, messagebox.showerror, "运行失败", str(exc))
        finally:
            self.running = False
            self.proc = None
            self.after(0, self.flash_btn.configure, {"state": "normal"})

if __name__ == "__main__":
    App().mainloop()
